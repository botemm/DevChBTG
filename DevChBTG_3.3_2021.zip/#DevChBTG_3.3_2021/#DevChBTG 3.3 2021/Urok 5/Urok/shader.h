class ShaderL
{
public:
	GLuint shaderProgram;
	std::string ErrorLog;

	ShaderL()
	{
	}

	ShaderL(char VS[],char FRAG[])
	{
		std::string VSs;
		std::string FRAGs;
		{

			//vertex
			std::ifstream File(VS);
			if(!File) {ErrorLog+="erorr open vs url:"; ErrorLog+=VS; ErrorLog+='\n';}
			else
			while(!File.eof())
			{
				VSs += File.get();
			}
			if(File) File.close();
		}

		{
			//fragment
			std::ifstream File(FRAG);
			if(!File) {ErrorLog+="erorr open frag:url:"; ErrorLog+=FRAG; ErrorLog+='\n';}
			else
			while(!File.eof())
			{
				FRAGs += File.get();
			}
			if(File) File.close();
		}
		

if(ErrorLog.size() == 0) //������� ����
{
	const GLchar* Verc = (GLchar*)VSs.c_str();
	// Build and compile our shader program
    // Vertex shader
    GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertexShader, 1, &Verc, NULL);
    glCompileShader(vertexShader);
    // Check for compile time errors
    GLint success;
    GLchar infoLog[512];
    glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShader, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;
    }


	const GLchar* Fragc = (GLchar*)FRAGs.c_str();
    // Fragment shader
    GLuint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShader, 1, &Fragc, NULL);
    glCompileShader(fragmentShader);
    // Check for compile time errors
    glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShader, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;
    }
    // Link shaders
    shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShader);
    glAttachShader(shaderProgram, fragmentShader);
    glLinkProgram(shaderProgram);
    // Check for linking errors
    glGetProgramiv(shaderProgram, GL_LINK_STATUS, &success);
    if (!success) {
        glGetProgramInfoLog(shaderProgram, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;
    }
    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);



	//std::cout<<std::endl<<"VS = "<<std::endl<<VSs.c_str()<<std::endl<<"FRAG = "<<std::endl<<FRAGs.c_str()<<std::endl<<ErrorLog.c_str()<<std::endl;
}
else //������� �
	std::cout<<ErrorLog.c_str()<<std::endl;
	}



	void setVec3(char set[],float x, float y,float z)
	{
        GLint poi = glGetUniformLocation(shaderProgram,  set);
        glUniform3f(poi, x, y, z);
	}


	void setVec4(char set[],float x, float y,float z,float s)
	{
        GLint poi = glGetUniformLocation(shaderProgram,  set);
        glUniform4f(poi, x, y, z,s);
	}





	void setFloat(char set[],float s)
	{	
        GLint poi = glGetUniformLocation(shaderProgram,  set);
		glUniform1f( poi,s);
	}


	void Use()
	{
		//���������� ���� �������� ��������
        glUseProgram(shaderProgram);
	}

	void setVec3(const char set[],glm::vec3 v)
	{
		GLint poi = glGetUniformLocation(shaderProgram,set);
		glUniform3f(poi, v.x, v.y, v.z);
	}

	void setMat4(const char set[],glm::mat4 v)
	{
		GLint poi = glGetUniformLocation(shaderProgram,set);
		glUniformMatrix4fv(poi, 1, GL_FALSE, glm::value_ptr(v));
	}

	void setInt(char set[],int s)
	{	
        GLint poi = glGetUniformLocation(shaderProgram,  set);
		glUniform1i( poi,s);
	}
	

};

