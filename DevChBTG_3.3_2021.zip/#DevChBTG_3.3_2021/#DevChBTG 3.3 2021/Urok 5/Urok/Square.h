﻿/*
Керування через шейдер замість меша напряму (рендор мешів лагає)
Предається стандартний меш координати 1 1 
Текстурні координати 1 1
В такому випадку в шейдер ми передаємо координати меша і текстурного квадрата 
Передеємо розміри обох кубів.
*/

class Square
{
	public:
	//Шейдер программа
	GLuint shaderProgramPlane;






	//Создать шейдер
	void CreateShader()
	{//--------------------------------
	GLuint vertexShader;
	vertexShader = glCreateShader(GL_VERTEX_SHADER);
	const GLchar* vertexShaderSourse = "#version 330 core\n"
		"layout(location=0) in vec2 TextCord;\n"
		"layout(location=1) in vec2 position;\n"
		"uniform vec2 S;\n"
		"uniform vec2 P;\n"
		"out vec2 TexCoords;\n"
		"void main()\n"
		"{\n"
		"TexCoords = TextCord;\n"
		"gl_Position = vec4(position.x*S.x+P.x,position.y*S.y+P.y,0,1);\n"
		"}\0";
	glShaderSource(vertexShader,1,&vertexShaderSourse,NULL);
	glCompileShader(vertexShader);

	{
		GLint success;
		GLchar infoLog[512];
		glGetShaderiv(vertexShader,GL_COMPILE_STATUS,&success);
		if(!success)
		{
			glGetShaderInfoLog(vertexShader,512,NULL,infoLog);
			std::cout<<"error vertex shader"<<std::endl<<infoLog<<std::endl;
		}
	}
	













	GLuint fragmentShader;
	fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	const GLchar* fragmentShaderSourse = "#version 330 core\n"
		"out vec4 color;\n"
		"in vec2 TexCoords;\n"
		"uniform sampler2D ourTexture;\n"
		"uniform vec4 colorUS;\n"
		"uniform int textureEnable;\n"
		"uniform vec2 Stx;\n" //Розміркуба текстурних кординат
		"uniform vec2 Ptx;\n" //Зміщення текстурних координат, через шейдер
		"void main()\n"
		"{\n"
		"vec2 TC = TexCoords;\n"
		"TC.x = TC.x * Stx.x + Ptx.x;\n"
		"TC.y = TC.y * Stx.y + Ptx.y;\n"
	//	"TexCoords.y = (TexCoords.y*Stx.y)+Ptx.y;\n"

		"if(textureEnable == 1)\n"
		"color = texture(ourTexture, TC)*colorUS;\n"
		"else\n"
		"color = colorUS;\n"
		"}\n"
		"\0";
	glShaderSource(fragmentShader,1,&fragmentShaderSourse,NULL);
	glCompileShader(fragmentShader);

	{
		GLint success;
		GLchar infoLog[512];
		glGetShaderiv(fragmentShader,GL_COMPILE_STATUS,&success);
		if(!success)
		{
			glGetShaderInfoLog(fragmentShader,512,NULL,infoLog);
			std::cout<<"Fragment Error"<<std::endl<<infoLog<<std::endl;
		}
	}
	


	shaderProgramPlane = glCreateProgram();
	glAttachShader(shaderProgramPlane,vertexShader);
	glAttachShader(shaderProgramPlane,fragmentShader);

	glLinkProgram(shaderProgramPlane);

	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);

	{
	GLint success;
	GLchar infoLog[512];
	glGetProgramiv(shaderProgramPlane,GL_LINK_STATUS,&success);
		if(!success)
		{
			glGetProgramInfoLog(shaderProgramPlane,512,NULL,infoLog);
			std::cout<<"error shader"<<std::endl<<infoLog<<std::endl;
		}

	}
	}//--------------------------------






	GLuint VAOparam,VBOpoints;

	void Comp()
	{
	//Создать VAO буфер
	glGenVertexArrays(1,&VAOparam);
	//Создать VBO буфер
	glGenBuffers(1,&VBOpoints);

	std::vector<float> Vertex2D;


	//Point A
	//tx
	Vertex2D.push_back(0);
	//ty
	Vertex2D.push_back(0);


	//x
	Vertex2D.push_back(-0.5);
	//y
	Vertex2D.push_back(-0.5);





	//Point B

	//tx
	Vertex2D.push_back(1);
	//ty
	Vertex2D.push_back(0);

	//x
	Vertex2D.push_back(0.5);
	//y
	Vertex2D.push_back(-0.5);




	//Point C
	//tx
	Vertex2D.push_back(1);
	//ty
	Vertex2D.push_back(1);


	//x
	Vertex2D.push_back(0.5);
	//y
	Vertex2D.push_back(0.5);


	//Point C
	//tx
	Vertex2D.push_back(1);
	//ty
	Vertex2D.push_back(1);


	//x
	Vertex2D.push_back(0.5);
	//y
	Vertex2D.push_back(0.5);




		//Point A
	//tx
	Vertex2D.push_back(0);
	//ty
	Vertex2D.push_back(0);


	//x
	Vertex2D.push_back(-0.5);
	//y
	Vertex2D.push_back(-0.5);








	//Point D

	//tx
	Vertex2D.push_back(0);
	//ty
	Vertex2D.push_back(1);

	//x
	Vertex2D.push_back(-0.5);
	//y
	Vertex2D.push_back(0.5);


	//Активировать VAO Буфер
	glBindVertexArray(VBOpoints);
		//Активировать VBO Буфер и связать переменную с буфером
		glBindBuffer(GL_ARRAY_BUFFER,VBOpoints);
			//Скопировать (координаты) в VBO  ==  GL_ARRAY_BUFFER
			glBufferData(GL_ARRAY_BUFFER,sizeof(float)*Vertex2D.size(),&Vertex2D[0],GL_STATIC_DRAW); //GL_STATIC_DRAW GL_DYNAMIC_DRAW GL_STREAM_DRAW
			//Как шейдер должен распознать точку Текстурные координаты
			glVertexAttribPointer(0,2,GL_FLOAT,GL_FALSE,4*sizeof(GL_FLOAT),(GLvoid*)0);
			//Активировать индекс layout
			glEnableVertexAttribArray(0);


			//Как шейдер должен распознать точку координаты
			glVertexAttribPointer(1,2,GL_FLOAT,GL_FALSE,4*sizeof(GL_FLOAT),(GLvoid*)(2 * sizeof(GL_FLOAT)));
			//Активировать индекс layout
			glEnableVertexAttribArray(1);


		//деактивирую наверное VBO Буфер
		glBindBuffer(GL_ARRAY_BUFFER,0);
	//деактивирую наверное VAO буфер
	glBindVertexArray(0);
	}
	
	//Розмір і позиція куба
	float SX,SY,X,Y;


	void SetSizeAndPos(float sx,float sy,float x,float y)
	{
		SX = sx;
		SY = sy;
		X = x;
		Y = y;
	}

	bool TextureEnable;
	void SetTextureEnable(bool Enable)
	{
		TextureEnable = Enable;
	}

	//Розмір і позиця текстури
	float txSX,txSY,txX,txY;
	void SetTxSizeAndPos(float sx,float sy,float x,float y)
	{
		txSX = sx;
		txSY = sy;
		txX = x;
		txY = y;
	}


	void Draw(GLuint Texture,float R,float G,float B,float A)
	{
				
		//Активировать шейдер
		glUseProgram(shaderProgramPlane);

		if(TextureEnable)
		{
			glActiveTexture(GL_TEXTURE0);
			glBindTexture(GL_TEXTURE_2D, Texture);
			glUniform1i(glGetUniformLocation(shaderProgramPlane, "ourTexture"), 0);
		}

		glUniform1i(glGetUniformLocation(shaderProgramPlane, "textureEnable"), TextureEnable);


		glUniform4f(glGetUniformLocation(shaderProgramPlane, "colorUS"), R/255,G/255,B/255,A/255);


		glUniform2f(glGetUniformLocation(shaderProgramPlane, "S"), SX,SY);
		glUniform2f(glGetUniformLocation(shaderProgramPlane, "P"), X,Y);

		glUniform2f(glGetUniformLocation(shaderProgramPlane, "Stx"), txSX,txSY);
		glUniform2f(glGetUniformLocation(shaderProgramPlane, "Ptx"), txX,txY);
		//glUniform1f(glGetUniformLocation(shaderProgramPlane, "sx"), SX);
		//glUniform1f(glGetUniformLocation(shaderProgramPlane, "sy"), SY);

		//Активировать vao
		glBindVertexArray(VAOparam);
		//Рисовать масив
		glDrawArrays(GL_TRIANGLES,0,6);
		//Не понятно вроде деактивирую
		glBindVertexArray(0);

		
	}


	Square()
	{
	}

	~Square()
	{
	}
};