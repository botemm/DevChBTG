<div  id = "ykorBlok"></div>
<script>

var Adres1 = "/pars/get.php?id=";
//Ідентифікатори доступу до даних
var GainParsID			= "Gain Z2";
var MonthlyParsID		= "Monthly Z2";
var TotalParsID			= "Daily Z2";
var MaximalParsID		= "Drawdown Z2";



//Дані для заповнення
var GainARa = "";
//var GainARn = "Total Gain for All Time";

var MonthlyARa = "";
//var MonthlyARn = "Monthly Profit";

var TotalARa = "";
//var TotalARn = "Total Number of Trading Days";

var MaximalARa = "";
//var MaximalARn = "Maximal Drawdown";



//==========================================================================================
function clear_S(text)
{
				var tempS = ""; 
				for(var i = 0;i < text.length;i++)
					if(text[i] != '%' && text[i] != '+') tempS = tempS+text[i];
				text = tempS;
				return text;
}
//==========================================================================================
//1 elem
{
	
//Рівень вкладення 0
var x = new XMLHttpRequest();  				//Об'єкт для запиту 
x.open("GET", Adres1 + GainParsID, true);   //Запит
x.onload = function ()						//Частина коду яка спрацює як тільки буде отримано дані
	{	
		GainARa = x.responseText; //Кладу отримані дані у змінну
		//1
		//Очистка даних
				{
				var tempS = ""; 
				for(var i = 0;i < GainARa.length;i++)
					if(GainARa[i] != '%' && GainARa[i] != '+') tempS = tempS+GainARa[i];
				GainARa = tempS;
				}
				
						//==================================2
						//2 elem
							{
							var y = new XMLHttpRequest(); 
							y.open("GET", Adres1 + MonthlyParsID, true); 
							y.onload = function ()
								{	
										MonthlyARa = y.responseText; 
									
										//2
										{
										var tempS = ""; 
										for(var i = 0;i < MonthlyARa.length;i++)
											if(MonthlyARa[i] != '%' && MonthlyARa[i] != '+') tempS = tempS+MonthlyARa[i];
										MonthlyARa = tempS;
										}
										//==================================3
										//3 elem
										{
										var z = new XMLHttpRequest(); 
										z.open("GET", Adres1 + TotalParsID, true); 
										z.onload = function ()
											{	
													TotalARa = z.responseText; 
														//3
														{
														var tempS = ""; 
														for(var i = 0;i < TotalARa.length;i++)
															if(TotalARa[i] != '%' && TotalARa[i] != '+') tempS = tempS+TotalARa[i];
														TotalARa = tempS;
														}
														
																	//=================================4
																	
																								//4 elem
																								{
																								var t = new XMLHttpRequest(); 
																								t.open("GET", Adres1 + MaximalParsID, true); 
																								t.onload = function ()
																									{	
																											MaximalARa = t.responseText; 
																										
																											//4
																											{
																											var tempS = ""; 
																											for(var i = 0;i < MaximalARa.length;i++)
																												if(MaximalARa[i] != '%' && MaximalARa[i] != '+') tempS = tempS+MaximalARa[i];
																											MaximalARa = tempS;
																											}
																											//=========================================================================================
																											var Code1 = "";
																											Code1 += '<div class="fusion-column-wrapper" style="background-position:left top;background-repeat:no-repeat;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;" data-bg-url="">';
																											Code1 += '<div class="fusion-counters-box counters-box row fusion-clearfix fusion-columns-4">';

																											Code1 += '<div class="fusion-counter-box fusion-column col-counter-box counter-box-wrapper col-lg-3 col-md-3 col-sm-3" data-animationoffset="100%">';
																												Code1 += '<div class="counter-box-container" style="border: 1px solid #e0dede;">';
																													Code1 += '<div id =  class="content-box-percentage content-box-counter" style="color:#a0ce4e;font-size:50px;line-height:normal;">';
																													Code1 += '<span id = "GainARaid" class="display-counter" data-value="0" data-direction="up" data-decimals="2">0</span><span class="unit">%</span>';
																													Code1 += '</div>';
																													Code1 += '<div  class="counter-box-content" style="color:#747474;font-size:17px;">Total Gain for All Time</div>';
																												Code1 += '</div>';
																											Code1 += '</div>';

																											Code1 += '<div class="fusion-counter-box fusion-column col-counter-box counter-box-wrapper col-lg-3 col-md-3 col-sm-3" data-animationoffset="100%"><div class="counter-box-container" style="border: 1px solid #e0dede;">';
																												Code1 += '<div  class="content-box-percentage content-box-counter" style="color:#a0ce4e;font-size:50px;line-height:normal;">';
																													Code1 += '<span id = "MonthlyARaid" class="display-counter" data-value="0" data-direction="up" data-decimals="2">0</span><span class="unit">%</span>';
																													Code1 += '</div>';
																													Code1 += '<div id = "MonthlyARn" class="counter-box-content" style="color:#747474;font-size:17px;">Monthly Profit</div>';
																												Code1 += '</div>';
																											Code1 += '</div>';

																											Code1 += '<div class="fusion-counter-box fusion-column col-counter-box counter-box-wrapper col-lg-3 col-md-3 col-sm-3" data-animationoffset="100%">';
																												Code1 += '<div class="counter-box-container" style="border: 1px solid #e0dede;">';
																													Code1 += '<div    class="content-box-percentage content-box-counter" style="color:#a0ce4e;font-size:50px;line-height:normal;">';
																													Code1 += '<span id = "TotalARaid" class="display-counter" data-value="0" data-direction="up" data-decimals="0">0</span><span class="unit">%</span>';
																													Code1 += '</div>';
																													Code1 += '<div   class="counter-box-content" style="color:#747474;font-size:17px;">Daily Profit</div>';
																												Code1 += '</div>';
																											Code1 += '</div>';

																											Code1 += '<div class="fusion-counter-box fusion-column col-counter-box counter-box-wrapper col-lg-3 col-md-3 col-sm-3" data-animationoffset="100%">';
																												Code1 += '<div class="counter-box-container" style="border: 1px solid #e0dede;" >';
																													Code1 += '<div    class="content-box-percentage content-box-counter" style="color:#a0ce4e;font-size:50px;line-height:normal;">';
																														Code1 += '<span id = "MaximalARaid" class="display-counter" data-value="0" data-direction="up" data-decimals="2">0</span><span class="unit">%</span>';
																													Code1 += '</div><div   class="counter-box-content" style="color:#747474;font-size:17px;">Maximal Drawdown</div>';
																												Code1 += '</div>';
																											Code1 += '</div>';

																											Code1 += '</div><div class="clearfix">';
																											Code1 += '</div><div class="fusion-clearfix"></div>';
																											Code1 += '</div>';
																											
																												document.getElementById("ykorBlok").innerHTML = Code1;
																												
																												
																											
																																													//GainARaid
																																													var Dilen = 50;
																																													var GainARat = 0;
																																													var MonthlyARat = 0;
																																													var TotalARat = 0;
																																													var MaximalARat = 0;
																																													var timer111 = setInterval(function(){
																																													//GainARaid
																																													
																																													
																																													
																																													
																																													
																																													if(GainARa > GainARat)
																																													{
																																													document.getElementById("GainARaid").innerHTML = Math.floor(Number(GainARat));
																																													GainARat+=Number(GainARa)/Dilen;
																																													
																																													//2
																																													document.getElementById("MonthlyARaid").innerHTML = Math.floor(Number(MonthlyARat));
																																													MonthlyARat+=Number(MonthlyARa)/Dilen;
																																													
																																													//3
																																													document.getElementById("TotalARaid").innerHTML = Math.floor(Number(TotalARat));
																																													TotalARat+=Number(TotalARa)/Dilen;
																																													
																																													//4
																																													document.getElementById("MaximalARaid").innerHTML = Math.floor(Number(MaximalARat));
																																													MaximalARat+=Number(MaximalARa)/Dilen;
																																													}
																																													else
																																													{
																																														document.getElementById("GainARaid").innerHTML = GainARa;
																																														document.getElementById("MonthlyARaid").innerHTML = MonthlyARa;
																																														document.getElementById("TotalARaid").innerHTML = TotalARa;
																																														document.getElementById("MaximalARaid").innerHTML = TotalARa;
																																														clearInterval(timer111);
																																													}
																																													
																																													
																																													
																																													;
																																													}, 50);
																											//=========================================================================================			

																									} 
																									t.send(null);
																								}

																	//=================================4
																	
											} 
											z.send(null);
										}
										//==================================3

								} 
								y.send(null);
							}

						//===================================2
	} 
	x.send(null);
}



/*

	//1
					document.getElementById("GainARa").innerHTML = '<span class="display-counter" data-value="'+GainARa+'" data-direction="up" data-decimals="2">'+GainARa+'</span><span class="unit">%</span>';
					document.getElementById("GainARn").innerHTML = GainARn;
					
							
			//2
			document.getElementById("MonthlyARa").innerHTML = '<span class="display-counter" data-value="'+MonthlyARa+'" data-direction="up" data-decimals="2">'+MonthlyARa+'</span><span class="unit">%</span>';
			document.getElementById("MonthlyARn").innerHTML = MonthlyARn;
	
			//4
			document.getElementById("MaximalARa").innerHTML = '<span class="display-counter" data-value="'+MaximalARa+'" data-direction="up" data-decimals="2">'+MaximalARa+'</span><span class="unit">%</span>';
			document.getElementById("MaximalARn").innerHTML = MaximalARn;
			
						//3
			document.getElementById("TotalARa").innerHTML = '<span class="display-counter" data-value="'+TotalARa+'" data-direction="up" data-decimals="0">'+TotalARa+'</span><span class="unit">Days</span>';
			document.getElementById("TotalARn").innerHTML = TotalARn;
			*/

</script>

