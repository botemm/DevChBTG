﻿#pragma warning(disable : 4996) 



bool SuccessTexture;
//Фушкція завантаження зображення
FIBITMAP * FreeIMloadImage(const char *filename)
{
	
    FIBITMAP *dib1 = NULL;
    FREE_IMAGE_FORMAT fif = FreeImage_GetFIFFromFilename(filename); //Дізнатись формат зображення

    dib1 = FreeImage_Load(fif, filename, JPEG_DEFAULT); //Завантажити саме зображення
    if (!dib1)
    {
       SuccessTexture = false;
	   return 0;
    } 
    SuccessTexture = true;
	
    return dib1;
}

//Функція перетворення зображення в текстуру
GLuint FreeIMloadTexture (FIBITMAP  * dib1)
{
    GLuint tex_id = 0;
    int x, y;
    int height, width;

    RGBQUAD rgbquad;
    FREE_IMAGE_TYPE type;
    BITMAPINFOHEADER *header;

	//Витягуємо дані з масиву в змінні
    type = FreeImage_GetImageType(dib1);
    height = FreeImage_GetHeight(dib1);
    width = FreeImage_GetWidth(dib1);
    header = FreeImage_GetInfoHeader(dib1);


	//Дізнатись скільки в одному пікселі цифер Наприклад якщо є альфа канал то не 3 а 4
    int scanLineWidh = ((3*width)%4 == 0) ? 3*width : ((3*width)/4)*4+4; 

	//Створюємо масив для пікселів
	unsigned char * texels= (GLubyte*)calloc(height*scanLineWidh, sizeof(GLubyte));
    
	
	//Заповнити масив пікселями з завантаженого зображення
	for (x=0 ; x<width ; x++)
   
		for (y=0 ; y<height; y++)
        {  
		  //Витягти з масива бібліотеки піксель
          FreeImage_GetPixelColor(dib1,x,y,&rgbquad);

		  //Заповнюємо масив
          texels[(y*scanLineWidh+3*x)]=((GLubyte*)&rgbquad)[2];
          texels[(y*scanLineWidh+3*x)+1]=((GLubyte*)&rgbquad)[1];
          texels[(y*scanLineWidh+3*x)+2]=((GLubyte*)&rgbquad)[0];
		  //Альфу якщо є пропускаємо
         }
		
		

		//Згенерувати текстура
        glGenTextures (1, &tex_id);
        glBindTexture (GL_TEXTURE_2D, tex_id);
		//Параметри згладжування текстури
        glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

		//Тепер на основі масива пікселей і даних генеруємо маму текстуру, без альфа каналу
        glTexImage2D (GL_TEXTURE_2D, 0, GL_RGB,  width, height, 0, GL_RGB,   GL_UNSIGNED_BYTE, texels);

		//Видалити масив пікселів
		free(texels);

	//Повернути ідентефікатор пікселів
      return tex_id;
}


//Оюєднуємо дві складні функції в просту
GLuint  FreeIMloadTexture(std::string filename)
{
	//створити змінну для ідентифікатора текстури
	GLuint texID;
	//Завантажити масив з зображенням
	FIBITMAP  *dib1 = FreeIMloadImage(filename.c_str());

	//Якщо невдача зупиняємо і повертаємо 0
	if(!SuccessTexture)
		return 0;


	//Згенерувати з зображення текстуру і отримати ідентифікатор
	texID = FreeIMloadTexture(dib1);
	//Видалити масив
    FreeImage_Unload(dib1);
	//Повернути ідентифікатор не текстуру
	return texID;
}



//2020
bool FreeIMloadTexture(std::string filename,int &W, int &H, GLuint &id)
{
 id = FreeIMloadTexture(filename);
 if(id == 0) return false; else return true;
}



