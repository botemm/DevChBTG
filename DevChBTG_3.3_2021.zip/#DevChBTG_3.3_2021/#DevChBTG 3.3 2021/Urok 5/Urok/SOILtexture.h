unsigned int SoILloadTexture(char const * path)
{
    unsigned int textureID;
    glGenTextures(1, &textureID);
	
    int width, height, nrComponents;
    unsigned char *data = SOIL_load_image(path, &width, &height, &nrComponents, 0);
    if (data)
    {
        GLenum format;
        if (nrComponents == 1)
            format = GL_RED;
        else if (nrComponents == 3)
            format = GL_RGB;
        else if (nrComponents == 4)
            format = GL_RGBA;
		
		//Алгоритм відображення текстурки
		std::vector<unsigned char>Vdat;
		
			//Розраховую розмір всього масиву
			int size = width * height * nrComponents;


			
			for(int i = height-1; i >= 0; i--)
			{
				for(int j = 0; j < width*nrComponents; j+=nrComponents)
				{
					if(nrComponents > 0) //R
						Vdat.push_back(data[i*width*nrComponents+j+0]);
					if(nrComponents > 2) //GB
					{
						Vdat.push_back(data[i*width*nrComponents+j+1]);
						Vdat.push_back(data[i*width*nrComponents+j+2]);
					}
					if(nrComponents > 3) //A
					{
						Vdat.push_back(data[i*width*nrComponents+j+3]);
					}
				}
			}

		
        glBindTexture(GL_TEXTURE_2D, textureID);
		//if(nrComponents == 3)
        glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, &Vdat[0]);
		//else
		//glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);


		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

		/*
        glGenerateMipmap(GL_TEXTURE_2D);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		SOIL_free_image_data(data);

		//*/
    }
    else
    {
        std::cout << "Texture failed to load at path: " << path << std::endl;
        SOIL_free_image_data(data);
    }
	
    return textureID;
}
