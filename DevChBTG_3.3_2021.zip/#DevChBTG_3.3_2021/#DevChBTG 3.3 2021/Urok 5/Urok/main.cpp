//Підключаємо ліб файли
#pragma comment(lib,"glfw3.lib")
#pragma comment(lib,"glew32d.lib")
#pragma comment(lib,"opengl32.lib")
#pragma comment(lib, "glew32s.lib")


#pragma comment(lib, "SOIL.lib")
#pragma comment (lib,"FreeImage.lib")
#pragma comment (lib,"glu32.lib")



//Підключаємо бібліотеки (послідовність важлива)
#include<GL\glew.h>
#include<GLFW\glfw3.h>
#include<iostream>
#include<math.h>


using namespace std;
#include"DevChBTG.h"


//#include<GL\FreeImage.h>
#include <SOIL.h>

// GLEW
#define GLEW_STATIC
#include <GL/glew.h>

//Дві бібліотеки для текстур
//#include "FreeIMtext.h"
#include "SOILtexture.h"

#include"Camera.h"
#include"transform.h"
#include"mesh.h"


DevChBTG::OBGECT *Text;

#include "Pane3_3.h"

#include"Square.h"

#include"objLoad.h"
Square Square1;

//Інтерфейс
DevChBTG GUI;


GLuint TestTexture;

//Розміри вікна
int WinWidth = 800,WinHeight = 600;
//U3 Змінна вікна
GLFWwindow *window;




GLuint TS;






//16 події
void Obrobka(string name,int id,int id2)
 {

	 if(name == "Exit")
	 {
		 exit(0);
	 }
	 else
	if(name == "ReForm")
	 {

		  GUI.Open("data\\forms\\FormIn.form");
		  //ConectForms();
		  //Помилки
		  	for(int i = 0; i < GUI.ErrorLog.size() ;i++)
			{
				std::cout<< GUI.ErrorLog[i]<<'\n';
			}
	}

}




//U3 
void key_func(GLFWwindow *window,int key,int scode,int action,int mode)
{
	//std::cout<<"key "<<key<<" scode "<<scode<<" action "<<action<<" mode "<<mode<<std::endl;
	if(key == GLFW_KEY_ESCAPE && mode == GLFW_MOD_SHIFT)
		glfwSetWindowShouldClose(window,GL_TRUE);
	return;
}


//U3 Drob
void drob_func(GLFWwindow *window,int count,const char** patch)
{
	system("cls");
	int i;
	for(i=0;i<count;i++)
	{
		std::cout<<patch[i]<<std::endl;
	}
	//std::cout<< <std::endl;
	return;
}





//**********************************************



void key_callback(GLFWwindow* window, int key, int scancode, int action, int mode)
{
	GUI.VoidSetKeyEvent(key,action,mode);




	//std::cout<<key<<std::endl;
	if(key == 294 && action == 1 )
	{
		Obrobka("ReForm",0,0);
	}


	return;	
}




//16
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
	GUI.windows_data.Maus_Data_.MausX_W = xpos;
	GUI.windows_data.Maus_Data_.MausY_W = ypos;
	return;
}

//16
void mouse_klick_func(GLFWwindow *window,int button,int action,int mods)
{

	GUI.windows_data.Maus_Data_.MausBT = button;
	GUI.windows_data.Maus_Data_.PressState = action;
	return;
}



void windowsResize(GLFWwindow *window,int W,int H)
{
	WinWidth = W;
	WinHeight = H;
}

//16 Завантаження текстур в графічну систему
bool loadTexture(std::string url,int &w,int &h, GLuint &id)
{
	id = SoILloadTexture(url.c_str());
	if(id == 0) return false; else return true;
}


bool loadTexture(std::string url, GLuint &id)
{
	id = SoILloadTexture(url.c_str());
	if(id == 0) return false; else return true;
}


//16
void character_callback(GLFWwindow* window, unsigned int codepoint)
{ 
	if(GUI.FontSystems.DefaultFonts < GUI.FontSystems.FontsArray.size())
	{
		codepoint = GUI.FontSystems.UnicodeToCharCode(codepoint,GUI.FontSystems.DefaultFonts);
		GUI.VoidSetKeyEventText(char(codepoint));
	}
}



//*********************
	//Створюю ідентифікатори для буферів
	GLuint VBOpoints,VAOparam;

	
	//Ідентифікатор шейдерної програми
	//GLuint shaderProgram;
	
//Функція малює квадрат по координатам Ця функція для 2.0 стандарту але користувач може вказати свою
void UserOpenGL3_3_DrawPlane(bool TextureEnable,GLuint TextureID,double x1,double y1,double tx1,double ty1,double x2,double y2,double tx2,double ty2,double x3,double y3,double tx3,double ty3,double x4,double y4,double tx4,double ty4,double R,double G,double B,double A)
{
	/*
		Square1.SetSizeAndPos(x2-x1,y4-y1,(x1+x2+x3+x4)/4,(y1+y2+y3+y4)/4);
	Square1.SetTxSizeAndPos(tx2-tx1,ty4-ty1,tx1,ty1);
	Square1.SetTextureEnable(TextureEnable);
	Square1.Draw(TextureID,R,G,B,A);
	*/


	Square1.SetSizeAndPos(x2-x1,y4-y1,(x1+x2+x3+x4)/4,(y1+y2+y3+y4)/4);
	Square1.SetTxSizeAndPos(tx2-tx1,ty4-ty1,tx1,ty1);
	Square1.SetTextureEnable(TextureEnable);
	Square1.Draw(TextureID,R,G,B,A);
	
}



DevChBTG::OBGECT *GetEL(std::string name)
{
	
	bool Su = true;
	DevChBTG::OBGECT *R =  &GUI.Get_Object(name,Su);
	if(!Su) 
	{
	std::cout<<"not found onject: "<< name << "\n";
	system("pause");
	}
	return R;
}


ObjLoad Test;

//Головна функція
int main()
{
	//Кирилиця
	setlocale(LC_ALL,"Russian");


	//Ініціалізація віконної бібліотеки
	glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	//Створюємо вікно
	window = glfwCreateWindow(WinWidth,WinHeight,"OpenGL 3.3",nullptr,nullptr);
	glfwMakeContextCurrent ( window );



	//Якщо вікно не створено
	if(window == nullptr)
	{
		std::cout<<"Помилка вiкно не створено"<<std::endl;
		glfwTerminate();
		system("pause");
		return -1;
	}






	//Використовуємо найновіші технології
	//glewExperimental = GL_TRUE;
    glewInit();


	//Ініціалізуємо і перевірка чи вдало (glew)
	if(glewInit() != GLEW_OK)
	{
		std::cout<<"glew не iнiцiалiзовано"<<std::endl;
		system("pause");
		glfwTerminate();
		return -1;
	}


	//Вибираємо вікно для малювання
	glfwMakeContextCurrent(window);


	 glfwGetFramebufferSize(window, &WinWidth, &WinHeight);  



	//U3 
	//Рееєстрація подій натиску клавіш (не залежно від розкладки)
	glfwSetKeyCallback(window,key_func);


	//U3 Вказуємо область і позицію малювання
	glfwGetFramebufferSize(window,&WinWidth,&WinHeight);

	//U3 drob (перетягування у вікно файлів)
	glfwSetDropCallback(window,drob_func);











	















	//glViewport(0,0,WinWidth/2,WinHeight/2);
	//Колір фону
	glClearColor(0.3,0.3,0.3,1);



	

		glfwSetKeyCallback(window,key_callback);
		glfwSetWindowSizeCallback (window,windowsResize);
		//16
		glfwSetCursorPosCallback(window, mouse_callback);
		glfwSetMouseButtonCallback(window,mouse_klick_func);
		glfwSetKeyCallback(window, key_callback);
		glfwSetCharCallback(window, character_callback);

		    // Set this to true so GLEW knows to use a modern approach to retrieving function pointers and extensions


	ShaderL test("shader\\test.vs","shader\\test.fs");								//Åêñïåðåìåíòàëüíèé
//	ShaderL SkyBoxSH("shader\\SkyBox\\SkyBox.vs","shader\\SkyBox\\SkyBox.fs");		//Äëÿ ñêàéáîêñà áåç âïëèâó ñâ³òëà
/*	ShaderL LightSH("shader\\light\\lighting.vs","shader\\light\\lighting.fs");    //Äëÿ âñÿêîãî ñâ³òëà
	ShaderL color("shader\\color\\color.vs","shader\\color\\color.fs");
	ShaderL plane("shader\\plane\\plane.vs","shader\\plane\\plane.fs");
	*/


	MeshStandartCNT skyBoxMesh(test);
	skyBoxMesh.LoadVertexTri("Cube.v");;
	skyBoxMesh.compile();

	unsigned int diffuseMap;// = LoTe();
	unsigned int specularMap; //; = LoTe("container2_specular.png");
	loadTexture("container2.png",diffuseMap);
	loadTexture("container2_specular.png",specularMap);


	glEnable(GL_TEXTURE_2D);

	//16 Фукція текстур
	GUI.setVoidTextureLoader(loadTexture);

	//16 Шрифти
	GUI.FontSystems.load("data\\fonts\\TNR.FTB");

	//16 Завантажити форми
	if(!GUI.Open("data\\forms1\\FormIn.form")) return 0;
	GUI.setFunctionDrawPlane(UserOpenGL3_3_DrawPlane);

	
		Square1.CreateShader();
		Square1.Comp();
		
		
		//loadTexture("data\\fonts\\TNR.png",TS);
		//GUI.FontSystems.DefaultFonts = TS;


		Camera camera;
		camera.Zoom = 30;
		camera.Position.x = -5;
		camera.Position.y = 0;
		camera.Position.z = 0;

float sss = 0;
	//Головний цикл
	while(!glfwWindowShouldClose(window)) //Доки вікно window не закрито
	{

				
		glfwPollEvents(); //Опрацьовуємо події
		glfwSwapBuffers(window); //Перемикання буферів (Подвійна буферезація)
		glViewport(0,0,WinWidth,WinHeight);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); //Замалювати фон вказаним раніше коліром
		


	 GUI.windows_data.WindowsWidth = WinWidth;
	 GUI.windows_data.WindowsHeight = WinHeight;
	 GUI.windows_data.ViewportPosX = 0;
	 GUI.windows_data.ViewportPosY = 0;
	 GUI.windows_data.ViewportWidth = WinWidth;
	 GUI.windows_data.ViewportHeight = WinHeight;
	 GUI.Time = glfwGetTime();


	 


	 	{
		test.Use();
        test.setVec3("viewPos", camera.Position);
		glm::mat4 projection = glm::perspective(glm::radians(camera.Zoom), (float)WinWidth / (float)WinHeight, 0.1f, 500.0f);
        test.setMat4("projection", projection);
		}


		test.Use();
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, diffuseMap);
		glUniform1i(glGetUniformLocation(test.shaderProgram, "ourTexture"), 0);
	

		{
		test.Use();
		TransformU Tra2;
		Tra2.translate(0,0,-5);
		Tra2.rotate(glfwGetTime(),glfwGetTime()/4,0);
		Tra2.scale(1);
		Tra2.active("view",test.shaderProgram);
		}


		{
		test.Use();
		TransformU Tra2;
		Tra2.translate(0,0,0);
		Tra2.scale(1);
		Tra2.active("model",test.shaderProgram);
		}







		glEnable(GL_DEPTH_TEST);
		skyBoxMesh.draw(GL_TRIANGLES);
		glDisable(GL_DEPTH_TEST);

		


		




	

	GUI.Draw(Obrobka);
	}


	glfwTerminate();
	return 1;
}





