#version 330 core
out vec4 FragColor;
in vec2 TexCoords;

uniform int mode;

uniform sampler2D ourTexture;
uniform vec4 color;
void main()
{  
  if(mode == 0)
  FragColor = texture(ourTexture, TexCoords);
  else
  if(mode == 1)
  FragColor = color;
  else
  if(mode == 2)
  FragColor = texture(ourTexture, TexCoords)*color;
  else
  FragColor = vec4(1,1,0,0.5);
  
  
   
    if(FragColor.a < 0.1)
        discard;
   
  
}

