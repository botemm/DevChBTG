#include<fstream>
using namespace std;

//Отключаем лишние придуприждения
#pragma warning(disable : 4996) 
#pragma warning(disable : 4018) 
#pragma warning(disable : 4244) 
#pragma warning(disable : 4805) 
#pragma warning(disable : 4244) 
#pragma warning(disable : 4101) 
#pragma warning(disable : 4800) 
#pragma warning(disable : 4872) 

class MeshStandartCNT //Ìåø òèïó êîðäèíàòè íîðìàë³ òåêñòóðí³ êîîðäèíàòè
{
private:
	int FRAG;//Çì³ííà ÿêà âêàçóº ÿêèì òèïîì áóëî çàâàíòàæåíî ìåø
	
public:
	int Vsize;

	bool Slot1,Slot2,Slot3,Slot4,Slot5;
	std::vector<float>VertexNormalTexture;
	GLuint diffuseMap;
	GLuint specularMap;
	GLuint normalMap;
	

	ShaderL SH;
	 unsigned int VBO, cubeVAO;

	MeshStandartCNT()
	{
	}

	MeshStandartCNT(ShaderL SHt)
	{
		Slot1 = 0,Slot2 = 0,Slot3 = 0,Slot4 = 0,Slot5 = 0;
		SH = SHt;
		FRAG = 0; //Âêàçóþ ùî äàí³ íå çàâàíòàæåí³
	}




public:
	bool LoadVertexTri(char *file)
	{

	std::cout<<file<<"\n";
	FRAG = 1; //Âêàçóþ ùî òóò ïîñë³äîâíî îïèñàí³ òðèêóòíèêè
	//Ñïî÷àòêó ê³ëüê³ñòü òî÷îê, à ïîò³ì ñàì³ òî÷êè äå îäíà ìàº ôîðìàò x.0 y.0 z.0 nx.0 ny.0 nz.0 tx.0 ty.0

	float value;
	ifstream in(file);
	if(!in){ cout<<"error file "; return 0; }
	int size; in>>size;
	std::vector<float>mas;
	for(int i = 0;i<size;i++)
	{
	in>>value;
	mas.push_back(value);
	}
	in.close();


	
    // first, configure the cube's VAO (and VBO)
    glGenVertexArrays(1, &cubeVAO);
    glGenBuffers(1, &VBO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
	int s = sizeof(float)*mas.size();
	glBufferData(GL_ARRAY_BUFFER, s, &mas[0], GL_STATIC_DRAW);
//	glBufferData(GL_ARRAY_BUFFER, sizeof(float) * VertexNormalTexture.size(), &VertexNormalTexture[0], GL_STATIC_DRAW);

    glBindVertexArray(cubeVAO);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

	Vsize = mas.size() / 8;

    // load textures (we now use a utility function to keep the code more organized)
    // -----------------------------------------------------------------------------
   // SH.setInt("material.diffuse", 0);
   //SH.setInt("material.specular", 1);
	return 1;
	}



bool CreateXYZ(std::vector<float> &vertex)
	{
	//FRAG = 1; //Âêàçóþ ùî òóò ïîñë³äîâíî îïèñàí³ òðèêóòíèêè
	//Ñïî÷àòêó ê³ëüê³ñòü òî÷îê, à ïîò³ì ñàì³ òî÷êè äå îäíà ìàº ôîðìàò x.0 y.0 z.0 nx.0 ny.0 nz.0 tx.0 ty.0

	float value;
	

	
    // first, configure the cube's VAO (and VBO)
    glGenVertexArrays(1, &cubeVAO);
    glGenBuffers(1, &VBO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
	int s = sizeof(float)*vertex.size();
	glBufferData(GL_ARRAY_BUFFER, s, &vertex[0], GL_STATIC_DRAW);
//	glBufferData(GL_ARRAY_BUFFER, sizeof(float) * VertexNormalTexture.size(), &VertexNormalTexture[0], GL_STATIC_DRAW);

    glBindVertexArray(cubeVAO);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

	Vsize = vertex.size() / 3;

    // load textures (we now use a utility function to keep the code more organized)
    // -----------------------------------------------------------------------------
   // SH.setInt("material.diffuse", 0);
   //SH.setInt("material.specular", 1);
	return 1;
	}



public:
	void draw(GLuint mod)
	{

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, diffuseMap);
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, specularMap);
        glBindVertexArray(cubeVAO);
        glDrawArrays(mod, 0, Vsize);
         
	}

	void compile()
	{
	}

	~MeshStandartCNT()
	{
	}
};
