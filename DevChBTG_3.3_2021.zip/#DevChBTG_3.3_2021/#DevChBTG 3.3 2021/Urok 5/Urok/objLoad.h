﻿class ObjLoad
{
public:
	//Коренева категорія
	std::string dir;

	//Колір з альфа каналом
	struct rgba
	{
		double R,G,B,A;
	};

	//Колір без альфа каналу
	struct rgb
	{
		double R,G,B;
	};

	//Точка на дві позиції
	struct v2
	{
		double A,B;
	};

	//Точка на три позиції
	struct v3
	{
		double A,B,C;
	};

	//Точка на чотири позиції
	struct v4
	{
		double A,B,C,D;
	};

	//Матеріал
	struct Material
	{
		std::string newmtl;  //Назва
		//Коляри
		rgb Ka;				 //Оточуюче освітлення
		rgb Kd;				 //Дифузорний колір
		rgb Ke;				 //Не знайшов в інеті по ходу випромінювання від слова emissin
		//Параметри відбивання
		rgb Ks;				 //Зиркальне відображення
		double Ns;			 //Коефіцієнт зеркального відображення від 0 до 1000
		//Прозорість
		double Tr;			 //Прозорість , ще позначають як d
		//Модель освітлення
		short illum;

		double Ni; //Коефіцієнт заломлення

		//Шлях до текстури
		std::string map_Kd;
		//Завантажена текстура
		GLuint TextID;
	};

	//Масив матеріалів
	std::vector<Material>Materials;

	//Прочитати стрічку
	std::string GetLine(std::string &str)
	{
		std::string Line = "";

		/*//Повидаляти пробіли
		while(str.size()>0)
		{
			if(str[0]==' ')
			{
				str.erase(str.begin()+0);
			}
			else
			break;
		}*/

		while(str.size()>0)
		{
			if(str[0]=='\n')
			{
				str.erase(str.begin()+0);
				break;
			}
			else
			{
				Line+=str[0];
				str.erase(str.begin()+0);
			}
		}
		return Line;
	}


	//Спец символи винесено у окрему функцію, щоб не повторювати себе і правити легше
	bool isSimvols(char c)
	{
		return (c == ' ' || c == '\\' || c == '/' ||  c == '\n'  || c == '\t');
	}

	//Прочитати слово і видалити його з маству повернути як ретурн
	std::string GetWord(std::string &str)
	{
		std::string word = "";

		while(str.size()>0)
		{
			if(isSimvols(str[0]))//Якщо в тексті  спец символ 
				str.erase(str.begin()+0); //Видаляємо
			else
				break;	//Інакше виходимо з циклу очистки.
		}


		while(str.size()>0)
		{
			if(isSimvols(str[0]))//Якщо в тексті  спец символ 
				break;	//Інакше виходимо з циклу читання слова.

			word+=str[0];
			str.erase(str.begin()+0); //Видаляємо	
		}


		
		//Підчистити все піля витягування слова
		while(str.size()>0)
		{
			if(isSimvols(str[0]))//Якщо в тексті  спец символ 
				str.erase(str.begin()+0); //Видаляємо
			else
				break;	//Інакше виходимо з циклу очистки.
		}


		return word;
	}

	rgb GetRGB(double r,double g, double b)
	{
		rgb C;
		C.R = r;
		C.G = g;
		C.B = b;
		return C;
	}

	Material MaterialDefault()
	{
		Material mt;
		mt.illum = 3;
		mt.Ka = GetRGB(0,0,0);
		mt.Kd = GetRGB(0.8,0.8,0.8);
		mt.Ks = GetRGB(1,1,1);
		mt.Ke = GetRGB(0,0,0);
		mt.map_Kd = "";
		mt.newmtl = "None";
		mt.Ni = 1.45;
		mt.Ns = 255;
		mt.TextID = 0;
		mt.Tr = 1;

		return mt;
	}







	bool ISusTextureLoader; //Чи призначав користувач функцію завантаження текстур
	//Функція для завантажена текстур при потребі розширити підтримук типів текстур визначається користувачем
	bool (*usTextureLoader)(std::string url, GLuint &TxID);
	void setVoidTextureLoader(bool (TextureLoaderA)(std::string url, GLuint &TxID))
	{
		usTextureLoader = TextureLoaderA;
		ISusTextureLoader = true;
		return;
	}




	//Відкрити матеріали
	bool OpenMaterials(std::string url)
	{
		

		std::string File = "";
		std::ifstream inFile(url.c_str());
		if(!inFile) return false;
		while(!inFile.eof())
		{
			File += tolower(inFile.get());
		}
		inFile.close();
		//Все фесь файл записали у змінну тепер розбираємо.


		Material Mt = MaterialDefault();
		
		while(File.size()>0)
		{
			std::string Word = GetWord(File);
		//	std::transform(Word.begin(),Word.end(),Word.begin(),tolower); //Перетворити в маленькі букви нижній регістр
			if(Word == "#") //Коментар
			{
				GetLine(File); //Викидаємо стрічку в пустоту
			}
			else
			if(Word == "newmtl")
			{
				Mt.newmtl = GetLine(File);
				Materials.push_back(Mt);
			}
			else
			if(Word == "ns")
			{
				if(Materials.size()>0)
				{
					
					Materials[Materials.size()-1].Ns = std::stof(GetWord(File));
				}
			}
			else
			if(Word == "ni")
			{
				if(Materials.size()>0)
				{
					
					Materials[Materials.size()-1].Ni = std::stof(GetWord(File));
				}
			}
			else
			if(Word == "tr" || Word == "d")
			{
				if(Materials.size()>0)
				{
					
					Materials[Materials.size()-1].Tr = std::stof(GetWord(File));
				}
			}
			else
			if(Word == "illum")
			{
				if(Materials.size()>0)
				{
					
					Materials[Materials.size()-1].illum = std::stof(GetWord(File));
				}
			}
			else
			if(Word == "kd")
			{
				if(Materials.size()>0)
				{
					Materials[Materials.size()-1].Kd.R = std::stof(GetWord(File));
					Materials[Materials.size()-1].Kd.G = std::stof(GetWord(File));
					Materials[Materials.size()-1].Kd.B = std::stof(GetWord(File));
				}
			}
			else
			if(Word == "ka")
			{
				if(Materials.size()>0)
				{
					Materials[Materials.size()-1].Ka.R = std::stof(GetWord(File));
					Materials[Materials.size()-1].Ka.G = std::stof(GetWord(File));
					Materials[Materials.size()-1].Ka.B = std::stof(GetWord(File));
				}
			}
			else
			if(Word == "ks")
			{
				if(Materials.size()>0)
				{
					Materials[Materials.size()-1].Ks.R = std::stof(GetWord(File));
					Materials[Materials.size()-1].Ks.G = std::stof(GetWord(File));
					Materials[Materials.size()-1].Ks.B = std::stof(GetWord(File));
				}
			}
			else
			if(Word == "ke")
			{
				if(Materials.size()>0)
				{
					Materials[Materials.size()-1].Ke.R = std::stof(GetWord(File));
					Materials[Materials.size()-1].Ke.G = std::stof(GetWord(File));
					Materials[Materials.size()-1].Ke.B = std::stof(GetWord(File));
				}
			}
			else
			if(Word == "map_kd") //Дифузорна текстура
			{
				if(Materials.size()>0)
				{
					Materials[Materials.size()-1].map_Kd = GetLine(File);

					if(ISusTextureLoader)
					{
						std::string nurl = dir;
						nurl+=Materials[Materials.size()-1].map_Kd;

						GLuint Ts = 0;
						usTextureLoader(nurl,Ts);
						if(!Ts)
							std::cout<<"error text load:" << nurl <<std::endl;

						Materials[Materials.size()-1].TextID = Ts;
					}


/*

						bool ISusTextureLoader; //Чи призначав користувач функцію завантаження текстур
	//Функція для завантажена текстур при потребі розширити підтримук типів текстур визначається користувачем
	bool (*usTextureLoader)(std::string url, GLuint &TxID);
	void setVoidTextureLoader(bool (TextureLoaderA)(std::string url, GLuint &TxID))
	{
		usTextureLoader = TextureLoaderA;
		ISusTextureLoader = true;
		return;
	}*/


				}	
			} //Доповнювати тут
	//	else 
		//	std::cout<<Word<<'\n';
		}





		//std::cout<<File.c_str();

		return true;
	}
//=============================================================================================================================
//=================================З матерыалами розыбралися далы меші=========================================================
	
	//Масиви врешин 
	std::vector<v3>Vertex;
	//Масив Текстурних координат
	std::vector<v2>TextCord;
	//Масив нормалів, їх в 3 рази менше так як одна нормаль йде на 3 точки
	std::vector<v3>Normals;


	//Масив ындексів матеріал назва і ще якийсь параметр s По суті меш
	struct Mesh
	{
		std::vector<v3>VertexIndex;
		std::vector<v3>TextCordIndex;
		std::vector<v3>NormalsIndex;
		std::string o; //name
		std::string usemtl;
		std::string s; 
	};

	//Обєкти окремо
	std::vector<Mesh>Onjects;









	//Прочитати можель повністю
	bool OpenModel(std::string url)
	{
		
		std::string File = "";
		std::ifstream inFile(url.c_str());
		if(!inFile) return false;
		while(!inFile.eof())
		{
			File += tolower(inFile.get());
		}
		inFile.close();

		/*//Все прочитане у маленькі букви
		for(int i = 0; i < File.size(); i++)
		{
			File[i] = tolower(File[i]);
		}*/
		//Все фесь файл записали у змінну тепер розбираємо.

		//Вижалити назву моделі вона нам більше не потрібна, але її коренева папка згодиться для відкриття матеріалів.

		while(url.size()>0)
		{
			if(url[url.size()-1] == '\\') {break;}
			url.erase(url.size()-1);
		}
		dir = url;
		
		while(File.size()>0)
		{
			std::string Word = GetWord(File);
			//tolower(Word.c_str());
			//transform(Word.begin(),Word.end(),Word.begin(),tolower); //Перетворити в маленькі букви нижній регістр
			if(Word == "#") //Коментар
			{
				GetLine(File); //Викидаємо стрічку в пустоту
			}
			else
			if(Word == "mtllib")
			{
				//Тут відкрити матеріал
				std::string Nurl = dir;
				Nurl += GetLine(File);
				if(!OpenMaterials(Nurl))
				{
					std::cout<<"URL:"<< Nurl << "\n";
				return false;
				}

			}
			else
			if(Word == "o")
			{
					Mesh mst;
					mst.o = GetLine(File);;
					Onjects.push_back(mst);

										//Materials[Materials.size()-1].Ns = std::stof(GetWord(File));
			}
			else
			if(Word == "v")
			{
					v3 temp;
					temp.A = std::stof(GetWord(File));
					temp.B = std::stof(GetWord(File));
					temp.C = std::stof(GetWord(File));

					Vertex.push_back(temp);
			}
			else
			if(Word == "vt")
			{
					v2 temp;
					temp.A = std::stof(GetWord(File));
					temp.B = std::stof(GetWord(File));

					TextCord.push_back(temp);
			}
			else
			if(Word == "vn")
			{
					v3 temp;
					temp.A = std::stof(GetWord(File));
					temp.B = std::stof(GetWord(File));
					temp.C = std::stof(GetWord(File));

					Normals.push_back(temp);
			}
			else
			if(Word == "usemtl")
			{
				if(Onjects.size()>0)
				{
					Onjects[Onjects.size()-1].usemtl = GetLine(File);
				}
			}
			else
			if(Word == "s")
			{
				if(Onjects.size()>0)
				{
					Onjects[Onjects.size()-1].s = GetLine(File);
				}
			}
			else
			if(Word == "f")
			{
				if(Onjects.size()>0)
				{
					
					v3 tempV;
					v3 tempT;
					v3 tempN;
					tempV.A = std::stof(GetWord(File));
					tempT.A = std::stof(GetWord(File));
					tempN.A = std::stof(GetWord(File));
								

					tempV.B = std::stof(GetWord(File));
					tempT.B = std::stof(GetWord(File));
					tempN.B = std::stof(GetWord(File));

			
					
					tempV.C = std::stof(GetWord(File));
					tempT.C = std::stof(GetWord(File));
					tempN.C = std::stof(GetWord(File));
					


					
					Onjects[Onjects.size()-1].VertexIndex.push_back(tempV);
					Onjects[Onjects.size()-1].TextCordIndex.push_back(tempT);
					Onjects[Onjects.size()-1].NormalsIndex.push_back(tempN);

				}
			}
		else 
			std::cout<<Word<<'\n';
		}



		//std::cout<<File.c_str();

		return true;
	}


	void V3Vertex(v3 v)
	{
		glVertex3d(v.A,v.B,v.C);
		return;
	}


	void V3Normal(v3 v)
	{
		glNormal3d(v.A,v.B,v.C);
		return;
	}

	
	void V2TextCord(v2 v)
	{
		glTexCoord2d(v.A,v.B);
		return;
	}

	bool UsMaterial(std::string name)
	{

		//transform(name.begin(),name.end(),name.begin(),tolower);
		for(int i = 0;i<Materials.size();i++)
		{
			//transform(Materials[i].map_Kd.begin(),Materials[i].map_Kd.end(),Materials[i].map_Kd.begin(),tolower);
			if(Materials[i].newmtl == name)
			{
				glBindTexture(GL_TEXTURE_2D, Materials[i].TextID);
			   glColor3f(Materials[i].Kd.R,Materials[i].Kd.G,Materials[i].Kd.B);
			   
			}
		}

	}
	

	void Draw()
	{

		for(int i = 0;i<Onjects.size();i++)
		{
			//mesh
			UsMaterial(Onjects[i].usemtl);
			glBegin(GL_TRIANGLES);
			for(int j = 0;j<Onjects[i].VertexIndex.size();j++) 
			{
				
				
				V3Normal(Vertex[Onjects[i].NormalsIndex[j].B-1]);

				V2TextCord(TextCord[Onjects[i].TextCordIndex[j].A-1]);		V3Vertex(Vertex[Onjects[i].VertexIndex[j].A-1]);
				V2TextCord(TextCord[Onjects[i].TextCordIndex[j].B-1]);		V3Vertex(Vertex[Onjects[i].VertexIndex[j].B-1]);
				V2TextCord(TextCord[Onjects[i].TextCordIndex[j].C-1]);		V3Vertex(Vertex[Onjects[i].VertexIndex[j].C-1]);
			}
			glEnd();
		}
	}

	ObjLoad()
	{
		ISusTextureLoader = false;
	}

	~ObjLoad()
	{
	}

};

