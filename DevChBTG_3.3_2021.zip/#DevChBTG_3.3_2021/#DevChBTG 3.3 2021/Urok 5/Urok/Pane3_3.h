﻿
class Plane3_3
{
public:
	//Шейдер программа
	GLuint shaderProgramPlane;

	//Структура одного полигона
	struct Mesh
	{
		GLuint Texture;
		GLuint VAOparam,VBOpoints;
		int Size;
		float R,G,B,A;
	};

	//Временный масив для компиляции в VAO
	vector<GLfloat>Vertex2D;

	//Набор меша 
	std::vector<Mesh>ArrMesh;
	//Екземпляр набора для сброса в масив
	Mesh Temp;


	//Задать цвет
	void Color4f(float R,float G,float B,float A)
	{
		Temp.R = R;
		Temp.G = G;
		Temp.B = B;
		Temp.A = A;
	}

	//Задать цвет в диапазоне  - 255
	void Color4uf(float R,float G,float B,float A)
	{
		Temp.R = R/255;
		Temp.G = G/255;
		Temp.B = B/255;
		Temp.A = A/255;
	}

	//Очистить временные переменные задать текстуру изза нее и цвета не могу месш вклеить в один vao
	void Begin(GLuint Texture)
	{
		
		
		Vertex2D.clear();
		Temp.VAOparam = 0;
		Temp.VBOpoints = 0;
		Temp.Texture = Texture;
		
	}


	//Отрендорить (Скомпилировать) и сбросить в масив
	void End()
	{
	//Создать VAO буфер
	glGenVertexArrays(1,&Temp.VAOparam);
	//Создать VBO буфер
	glGenBuffers(1,&Temp.VBOpoints);

	//Активировать VAO Буфер
	glBindVertexArray(Temp.VBOpoints);
		//Активировать VBO Буфер и связать переменную с буфером
		glBindBuffer(GL_ARRAY_BUFFER,Temp.VBOpoints);
			//Скопировать (координаты) в VBO  ==  GL_ARRAY_BUFFER
			glBufferData(GL_ARRAY_BUFFER,sizeof(float)*Vertex2D.size(),&Vertex2D[0],GL_STREAM_DRAW); //GL_STATIC_DRAW GL_DYNAMIC_DRAW GL_STREAM_DRAW
			//Как шейдер должен распознать точку Текстурные координаты
			glVertexAttribPointer(0,2,GL_FLOAT,GL_FALSE,4*sizeof(GL_FLOAT),(GLvoid*)0);
			//Активировать индекс layout
			glEnableVertexAttribArray(0);


			//Как шейдер должен распознать точку координаты
			glVertexAttribPointer(1,2,GL_FLOAT,GL_FALSE,4*sizeof(GL_FLOAT),(GLvoid*)(2 * sizeof(GL_FLOAT)));
			//Активировать индекс layout
			glEnableVertexAttribArray(1);


		//деактивирую наверное VBO Буфер
		glBindBuffer(GL_ARRAY_BUFFER,0);
	//деактивирую наверное VAO буфер
	glBindVertexArray(0);

	Temp.Size = Vertex2D.size()/4;

	//Сброс в масив
	ArrMesh.push_back(Temp);
	}

	//Создать шейдер
	void CreateShader()
	{//--------------------------------
	GLuint vertexShader;
	vertexShader = glCreateShader(GL_VERTEX_SHADER);
	const GLchar* vertexShaderSourse = "#version 330 core\n"
		"layout(location=0) in vec2 TextCord;\n"
		"layout(location=1) in vec2 position;\n"
		"out vec2 TexCoords;\n"
		"void main()\n"
		"{\n"
		"TexCoords = TextCord;\n"
		"gl_Position = vec4(position.x,position.y,0,1);\n"
		"}\0";
	glShaderSource(vertexShader,1,&vertexShaderSourse,NULL);
	glCompileShader(vertexShader);

	{
		GLint success;
		GLchar infoLog[512];
		glGetShaderiv(vertexShader,GL_COMPILE_STATUS,&success);
		if(!success)
		{
			glGetShaderInfoLog(vertexShader,512,NULL,infoLog);
			std::cout<<"error vertex shader"<<std::endl<<infoLog<<std::endl;
		}
	}
	













	GLuint fragmentShader;
	fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	const GLchar* fragmentShaderSourse = "#version 330 core\n"
		"out vec4 color;\n"
		"in vec2 TexCoords;\n"
		"uniform sampler2D ourTexture;\n"
		"uniform vec4 colorUS;\n"
		//"uniform float textureEnable;\n"
		"void main()\n"
		"{\n"
		"color = texture(ourTexture, TexCoords)*colorUS;\n"
		"}\n"
		"\0";
	glShaderSource(fragmentShader,1,&fragmentShaderSourse,NULL);
	glCompileShader(fragmentShader);

	{
		GLint success;
		GLchar infoLog[512];
		glGetShaderiv(fragmentShader,GL_COMPILE_STATUS,&success);
		if(!success)
		{
			glGetShaderInfoLog(fragmentShader,512,NULL,infoLog);
			std::cout<<"Fragment Error"<<std::endl<<infoLog<<std::endl;
		}
	}
	


	shaderProgramPlane = glCreateProgram();
	glAttachShader(shaderProgramPlane,vertexShader);
	glAttachShader(shaderProgramPlane,fragmentShader);

	glLinkProgram(shaderProgramPlane);

	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);

	{
	GLint success;
	GLchar infoLog[512];
	glGetProgramiv(shaderProgramPlane,GL_LINK_STATUS,&success);
		if(!success)
		{
			glGetProgramInfoLog(shaderProgramPlane,512,NULL,infoLog);
			std::cout<<"error shader"<<std::endl<<infoLog<<std::endl;
		}

	}
	}//--------------------------------













	


	//Добавить точку
	void AddPoint(float tx, float ty,float x,float y)
	{
		Vertex2D.push_back(tx);
		Vertex2D.push_back(ty);

		Vertex2D.push_back(x);
		Vertex2D.push_back(y);
	}



	//Рисовать все
	void Draw()
	{
	
		Text->Text = "Draw";
				
		//Активировать шейдер
		glUseProgram(shaderProgramPlane);

		for(int i = 0; i<ArrMesh.size();i++)
		{

	    glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, ArrMesh[i].Texture);
        glUniform1i(glGetUniformLocation(shaderProgramPlane, "ourTexture"), 0);


		glUniform4f(glGetUniformLocation(shaderProgramPlane, "colorUS"), ArrMesh[i].R,ArrMesh[i].G,ArrMesh[i].B,ArrMesh[i].A);

		//Активировать vao
		glBindVertexArray(ArrMesh[i].VAOparam);
		//Рисовать масив
		glDrawArrays(GL_TRIANGLES,0,ArrMesh[i].Size);
		//Не понятно вроде деактивирую
		glBindVertexArray(0);

		}

	}


//Очистить все
	void Clear()
	{
		Text->Text = "Clear";
		for(int i = 0; i<ArrMesh.size();i++)
		{
		glDeleteVertexArrays(1,&ArrMesh[i].VAOparam);
		glDeleteBuffers(1,&ArrMesh[i].VBOpoints);
		}
		ArrMesh.clear();
	}




	Plane3_3()
	{
		Temp.R = 1;
		Temp.G = 1;
		Temp.B = 1;
		Temp.A = 1;
	}

	~Plane3_3()
	{
	}
};