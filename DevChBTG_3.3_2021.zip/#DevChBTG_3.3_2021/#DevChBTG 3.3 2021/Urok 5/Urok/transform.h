// GLM Mathematics
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include"shader.h"


class TransformU
{
public:
	TransformU()
	{
	}

	glm::mat4 mat;

	
		void translate(float x,float y, float z)
		{
			mat = glm::translate(mat, glm::vec3(x, y, z));
		}

		void g_translate(glm::vec3 a)
		{
			mat = glm::translate(mat, a);
		}


		void scale(float x,float y, float z)
		{
			mat = glm::scale(mat, glm::vec3(x, y, z));
		}

		void scale(float s)
		{
			mat = glm::scale(mat, glm::vec3(s, s, s));
		}


		void rotate(float x,float y, float z)
		{
			mat = glm::rotate(mat,x * 1.0f, glm::vec3(1.0f, 0.0f, 0.0f));
			mat = glm::rotate(mat,y * 1.0f, glm::vec3(0.0f, 1.0f, 0.0f));
			mat = glm::rotate(mat,z * 1.0f, glm::vec3(0.0f, 0.0f, 1.0f));
		}

		void active(char *name,GLuint &Shader)
		{
				GLuint transformLoc = glGetUniformLocation(Shader, name);
				glUniformMatrix4fv(transformLoc, 1, GL_FALSE, glm::value_ptr(mat));
		}







	~TransformU()
	{
	}
};

void g_translate(glm::mat4 &mat,float x,float y, float z)
{
	mat = glm::translate(mat, glm::vec3(x, y, z));
}

void g_translate(glm::mat4 &mat,glm::vec3 a)
{
	mat = glm::translate(mat, a);
}

void g_scale(glm::mat4 &mat,float x,float y, float z)
{
	mat = glm::scale(mat, glm::vec3(x, y, z));
}

void g_scale(glm::mat4 &mat,float s)
{
	g_scale(mat,s,s, s);
}


void g_rotate(glm::mat4 &mat,float x,float y, float z)
{
	mat = glm::rotate(mat,x * 1.0f, glm::vec3(1.0f, 0.0f, 0.0f));
	mat = glm::rotate(mat,y * 1.0f, glm::vec3(0.0f, 1.0f, 0.0f));
	mat = glm::rotate(mat,z * 1.0f, glm::vec3(0.0f, 0.0f, 1.0f));
}

void g_active(glm::mat4 &mat,char *name,GLuint &Shader)
{
		GLuint transformLoc = glGetUniformLocation(Shader, name);
		glUniformMatrix4fv(transformLoc, 1, GL_FALSE, glm::value_ptr(mat));
}

